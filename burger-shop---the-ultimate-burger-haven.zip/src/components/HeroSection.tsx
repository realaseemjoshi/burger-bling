import React from 'react';
import { Heart, Maximize2, Sparkles } from 'lucide-react';
import { BurgerItem } from '../data/burgers';

interface HeroSectionProps {
  burgers: BurgerItem[];
  selectedIndex: number;
  onSelectBurger: (index: number) => void;
  onOrderNow: (burger: BurgerItem) => void;
  onViewMenu: () => void;
  onZoomBurger: (burger: BurgerItem) => void;
  isLiked: boolean;
  onToggleLike: () => void;
  likesCount: number;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  burgers,
  selectedIndex,
  onSelectBurger,
  onOrderNow,
  onViewMenu,
  onZoomBurger,
  isLiked,
  onToggleLike,
  likesCount,
}) => {
  const currentBurger = burgers[selectedIndex] || burgers[2];

  return (
    <section id="home" className="relative w-full min-h-[calc(100vh-100px)] flex flex-col justify-between px-6 sm:px-10 lg:px-16 pt-2 pb-10">
      {/* Main Grid: Left copy & actions, Right featured burger */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-4 items-center my-auto">
        
        {/* Left Column: Headlines, Paragraph, CTAs */}
        <div className="lg:col-span-6 z-10 flex flex-col justify-center max-w-xl">
          {/* Main Display Headline */}
          <div className="mb-4">
            <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl xl:text-7xl font-black uppercase text-white tracking-wider leading-[0.95] drop-shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
              {currentBurger.headlineFirst}
              <br />
              <span className="text-white block mt-1">
                {currentBurger.headlineSecond}
              </span>
            </h1>
          </div>

          {/* Subtitle / Paragraph */}
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed mb-8 max-w-lg font-normal text-balance">
            {currentBurger.description}
          </p>

          {/* Action CTAs: Order Now & View Menu */}
          <div className="flex items-center gap-6 mb-10 sm:mb-12">
            <button
              onClick={() => onOrderNow(currentBurger)}
              className="group relative inline-flex items-center justify-center px-7 py-3 rounded-xl text-sm sm:text-base font-semibold text-white bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 shadow-[0_4px_25px_rgba(249,115,22,0.45)] hover:shadow-[0_6px_30px_rgba(249,115,22,0.65)] hover:brightness-110 active:scale-95 transition-all duration-200 cursor-pointer"
            >
              <span>Order Now</span>
            </button>

            <button
              onClick={onViewMenu}
              className="text-orange-400 hover:text-orange-300 font-semibold text-sm sm:text-base transition-colors duration-200 cursor-pointer hover:underline underline-offset-4"
            >
              View Menu
            </button>
          </div>

          {/* Bottom Thumbnail Strip */}
          <div className="pt-2">
            <div className="flex items-end gap-3 sm:gap-4">
              {burgers.map((burger, idx) => {
                const isSelected = idx === selectedIndex;
                return (
                  <div key={burger.id} className="relative flex flex-col items-center">
                    {/* Active Indicator Arrow Pointer */}
                    {isSelected ? (
                      <div className="mb-1 text-orange-500 transition-all duration-300 animate-bounce">
                        <svg className="w-3.5 h-2.5 fill-current" viewBox="0 0 14 10">
                          <polygon points="0,0 14,0 7,10" />
                        </svg>
                      </div>
                    ) : (
                      <div className="h-3.5 mb-1" />
                    )}

                    {/* Thumbnail Card */}
                    <button
                      onClick={() => onSelectBurger(idx)}
                      className={`relative w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden cursor-pointer transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 ${
                        isSelected
                          ? 'border-2 border-orange-500 ring-2 ring-orange-500/30 scale-105 shadow-[0_0_20px_rgba(249,115,22,0.35)]'
                          : 'border border-neutral-700/80 hover:border-neutral-400 bg-neutral-900/60 opacity-80 hover:opacity-100'
                      }`}
                      aria-label={`Select ${burger.name}`}
                    >
                      <img
                        src={burger.thumbImage}
                        alt={burger.name}
                        className="w-full h-full object-cover object-center transform hover:scale-110 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Featured Flying Burger and Floating Side Actions */}
        <div className="lg:col-span-6 relative flex items-center justify-center lg:justify-end">
          {/* Main Floating Burger Showcase */}
          <div className="relative w-full max-w-lg lg:max-w-xl xl:max-w-2xl flex items-center justify-center">
            {/* Subtle backlight glow matching the food rim lighting */}
            <div className="absolute inset-0 bg-gradient-to-tr from-orange-600/10 via-transparent to-amber-500/5 blur-3xl rounded-full pointer-events-none" />

            {/* The Floating Burger Image */}
            <div className="relative z-10 w-full animate-float transition-all duration-500">
              <img
                key={currentBurger.id}
                src={currentBurger.image}
                alt={currentBurger.name}
                className="w-full h-auto max-h-[580px] object-contain drop-shadow-[0_25px_35px_rgba(0,0,0,0.9)] cursor-pointer select-none"
                onClick={() => onZoomBurger(currentBurger)}
                title="Click to view details"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Floating Action Controls on Right Edge (exact match to screenshot) */}
            <aside aria-label="Quick burger actions" className="absolute right-0 sm:right-2 bottom-12 sm:bottom-16 z-20 flex flex-col items-center gap-3">
              {/* Glass Pill with Like Heart & Expand Icons */}
              <div className="flex flex-col items-center bg-neutral-900/70 backdrop-blur-md border border-neutral-700/60 rounded-2xl p-2 gap-3 shadow-xl">
                {/* Heart Button */}
                <button
                  onClick={onToggleLike}
                  className="p-1.5 rounded-xl hover:bg-white/10 transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-orange-500 group"
                  title={isLiked ? 'Unlike' : 'Like this burger'}
                  aria-label={isLiked ? 'Unlike' : 'Like this burger'}
                >
                  <Heart
                    className={`w-6 h-6 transition-all duration-200 ${
                      isLiked
                        ? 'fill-red-500 text-red-500 scale-110'
                        : 'text-neutral-300 group-hover:text-white stroke-[2]'
                    }`}
                  />
                </button>

                {/* Fullscreen Expand / Zoom Button */}
                <button
                  onClick={() => onZoomBurger(currentBurger)}
                  className="p-1.5 rounded-xl hover:bg-white/10 transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-orange-500 text-neutral-300 hover:text-white"
                  title="Expand preview"
                  aria-label="Expand preview"
                >
                  <Maximize2 className="w-5 h-5 stroke-[2]" />
                </button>
              </div>

              {/* Sparkle Count Widget (42 in screenshot) */}
              <div className="flex flex-col items-center justify-center bg-neutral-900/70 backdrop-blur-md border border-neutral-700/60 rounded-2xl px-3 py-2 shadow-xl min-w-[52px]">
                <span className="font-heading text-sm font-bold text-white tracking-wider tabular-nums">
                  {likesCount}
                </span>
                <Sparkles className="w-4 h-4 text-orange-400 mt-0.5" />
              </div>
            </aside>
          </div>
        </div>
      </div>
    </section>
  );
};
