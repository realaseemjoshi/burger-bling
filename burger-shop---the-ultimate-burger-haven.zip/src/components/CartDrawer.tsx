import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, CheckCircle2, Clock, MapPin } from 'lucide-react';
import { CartItem } from '../data/burgers';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, newQty: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  if (!isOpen) return null;

  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoMessage, setPromoMessage] = useState('');
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');

  // Checkout form state
  const [formData, setFormData] = useState({
    name: 'Alex Mercer',
    phone: '+1 (555) 349-8821',
    address: '428 Gourmet Boulevard, Apt 4B',
    instructions: 'Leave at front desk, buzzer #42',
  });

  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const discountAmount = (subtotal * discountPercent) / 100;
  const deliveryFee = subtotal > 25 || subtotal === 0 ? 0 : 3.5;
  const taxes = (subtotal - discountAmount) * 0.0825;
  const grandTotal = Math.max(0, subtotal - discountAmount + deliveryFee + taxes);

  const applyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim().toUpperCase() === 'HAVEN20') {
      setDiscountPercent(20);
      setPromoMessage('20% Haven discount applied!');
    } else if (promoCode.trim().toUpperCase() === 'BURGER') {
      setDiscountPercent(15);
      setPromoMessage('15% VIP discount applied!');
    } else {
      setPromoMessage('Invalid code. Try "HAVEN20"');
    }
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('success');
  };

  const handleResetAndClose = () => {
    onClearCart();
    setStep('cart');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-neutral-950 border-l border-neutral-800 h-full flex flex-col shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-orange-500" />
            <span className="font-heading text-lg font-bold text-white uppercase tracking-wider">
              {step === 'cart'
                ? 'Your Order Bag'
                : step === 'checkout'
                ? 'Delivery Details'
                : 'Order Confirmed!'}
            </span>
          </div>
          <button
            onClick={step === 'success' ? handleResetAndClose : onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
            aria-label="Close Bag"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Views */}
        {step === 'cart' && (
          <>
            {items.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-neutral-900 flex items-center justify-center mb-4 text-neutral-500">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-heading text-white text-base font-bold mb-1">
                  Your bag is empty
                </h3>
                <p className="text-neutral-400 text-xs max-w-xs mb-6">
                  Add some delicious flame-grilled burgers or artisan sides to begin your feast.
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl font-semibold text-xs bg-orange-500 hover:bg-orange-600 text-white transition-colors"
                >
                  Explore Menu
                </button>
              </div>
            ) : (
              <>
                {/* Free Delivery Bar */}
                <div className="px-6 py-2.5 bg-neutral-900/60 border-b border-neutral-800 text-xs">
                  {subtotal >= 25 ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" /> You unlocked Free Express Delivery!
                    </span>
                  ) : (
                    <span className="text-neutral-300">
                      Add <strong className="text-orange-400">${(25 - subtotal).toFixed(2)}</strong> more for free delivery
                    </span>
                  )}
                </div>

                {/* Items List */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-3 p-3 bg-neutral-900/40 rounded-xl border border-neutral-800/80"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-14 h-14 rounded-lg object-cover border border-neutral-800 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white text-xs font-bold truncate">
                          {item.name}
                        </h4>
                        {item.bunType !== 'N/A' && (
                          <p className="text-[11px] text-neutral-400 truncate">
                            {item.bunType}
                            {item.extraToppings.length > 0 && ` • +${item.extraToppings.length} extras`}
                          </p>
                        )}
                        <div className="text-orange-400 font-semibold text-xs mt-1 tabular-nums">
                          ${(item.price * item.quantity).toFixed(2)}
                        </div>
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-1.5 bg-neutral-950 px-2 py-1 rounded-lg border border-neutral-800">
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                          className="text-neutral-400 hover:text-white p-0.5"
                          aria-label="Decrease quantity"
                        >
                          {item.quantity === 1 ? (
                            <Trash2 className="w-3.5 h-3.5 text-red-400" />
                          ) : (
                            <Minus className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <span className="text-xs text-white font-bold w-4 text-center tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                          className="text-neutral-400 hover:text-white p-0.5"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Promo Code Input */}
                  <form onSubmit={applyPromo} className="pt-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Promo code (HAVEN20)"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-orange-500 uppercase tracking-wider"
                      />
                      <button
                        type="submit"
                        className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs rounded-lg transition-colors"
                      >
                        Apply
                      </button>
                    </div>
                    {promoMessage && (
                      <p
                        className={`text-[11px] mt-1.5 ${
                          discountPercent > 0 ? 'text-emerald-400' : 'text-neutral-400'
                        }`}
                      >
                        {promoMessage}
                      </p>
                    )}
                  </form>
                </div>

                {/* Bill Breakdown & Checkout Button */}
                <div className="p-6 border-t border-neutral-800 bg-neutral-950/80 space-y-2">
                  <div className="flex justify-between text-xs text-neutral-400">
                    <span>Subtotal</span>
                    <span className="tabular-nums font-semibold text-neutral-200">
                      ${subtotal.toFixed(2)}
                    </span>
                  </div>
                  {discountPercent > 0 && (
                    <div className="flex justify-between text-xs text-emerald-400">
                      <span>Discount ({discountPercent}%)</span>
                      <span className="tabular-nums">-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xs text-neutral-400">
                    <span>Delivery</span>
                    <span className="tabular-nums">
                      {deliveryFee === 0 ? 'FREE' : `$${deliveryFee.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs text-neutral-400">
                    <span>Estimated Tax (8.25%)</span>
                    <span className="tabular-nums">${taxes.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-neutral-800">
                    <span>Total</span>
                    <span className="text-orange-400 font-heading text-lg tabular-nums">
                      ${grandTotal.toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={() => setStep('checkout')}
                    className="w-full mt-4 py-3 rounded-xl font-semibold text-sm bg-gradient-to-r from-orange-600 to-amber-500 text-white hover:brightness-110 shadow-[0_0_20px_rgba(249,115,22,0.4)] flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Proceed to Delivery</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </>
        )}

        {/* Step: Checkout Details Form */}
        {step === 'checkout' && (
          <form onSubmit={handlePlaceOrder} className="flex-1 flex flex-col justify-between p-6">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Recipient Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Delivery Address
                </label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Delivery Notes
                </label>
                <textarea
                  rows={2}
                  value={formData.instructions}
                  onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                  className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>

              {/* Payment Method Selector */}
              <div className="pt-2">
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                  Payment Method
                </label>
                <div className="p-3 rounded-xl border border-orange-500/60 bg-orange-500/10 flex items-center justify-between text-xs text-white font-medium">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
                    <span>Cash on Delivery / Card at Door</span>
                  </div>
                  <span className="text-orange-400 font-bold tabular-nums">
                    ${grandTotal.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-6 border-t border-neutral-800">
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-orange-600 to-amber-500 text-white hover:brightness-110 shadow-[0_0_20px_rgba(249,115,22,0.4)] cursor-pointer"
              >
                Confirm Order (${grandTotal.toFixed(2)})
              </button>
              <button
                type="button"
                onClick={() => setStep('cart')}
                className="w-full py-2 text-xs text-neutral-400 hover:text-white transition-colors"
              >
                ← Back to Order Bag
              </button>
            </div>
          </form>
        )}

        {/* Step: Order Success Screen */}
        {step === 'success' && (
          <div className="flex-1 flex flex-col justify-between p-6 text-center">
            <div className="my-auto space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="font-heading text-xl font-bold text-white uppercase tracking-wider">
                Order Placed!
              </h3>
              <p className="text-neutral-300 text-xs max-w-xs mx-auto leading-relaxed">
                Thank you, <strong className="text-white">{formData.name}</strong>! Your burger is now sizzling on our woodfire grill.
              </p>

              {/* Order Status Box */}
              <div className="bg-neutral-900/60 p-4 rounded-xl border border-neutral-800 text-left space-y-2.5 text-xs text-neutral-300 max-w-sm mx-auto">
                <div className="flex items-center justify-between text-neutral-400">
                  <span>Order Reference</span>
                  <span className="font-mono text-orange-400 font-bold">#HVN-8842</span>
                </div>
                <div className="flex items-center gap-2 text-neutral-300">
                  <Clock className="w-4 h-4 text-orange-400 shrink-0" />
                  <span>Estimated Arrival: <strong>18–25 mins</strong></span>
                </div>
                <div className="flex items-center gap-2 text-neutral-300">
                  <MapPin className="w-4 h-4 text-orange-400 shrink-0" />
                  <span className="truncate">{formData.address}</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleResetAndClose}
              className="w-full py-3 rounded-xl font-semibold text-xs bg-neutral-800 hover:bg-neutral-700 text-white transition-colors"
            >
              Done & Return to Haven
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
