import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, MessageSquare } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    inquiryType: 'Table Reservation',
    guests: '2 Guests',
    message: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;
    setIsSubmitted(true);
    setTimeout(() => {
      // Keep confirmation visible
    }, 500);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      inquiryType: 'Table Reservation',
      guests: '2 Guests',
      message: '',
    });
    setIsSubmitted(false);
  };

  return (
    <section id="contact" className="relative w-full py-24 px-6 sm:px-10 lg:px-16 border-t border-neutral-900 bg-black">
      <div className="max-w-6xl mx-auto">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-orange-500 uppercase tracking-[0.25em] mb-3">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Connect & Dine</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-black text-white uppercase tracking-wider leading-[1.05]">
            VISIT THE HAVEN
            <br />
            <span className="text-orange-500">OR RESERVE A TABLE</span>
          </h2>
          <p className="mt-5 text-neutral-400 text-sm sm:text-base leading-relaxed">
            Whether you want to reserve our woodfire chef's counter, plan private catering, or ask about our ingredients, we'd love to hear from you.
          </p>
        </div>

        {/* 2-Column Grid: Location Info & Interactive Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left Column: Address, Hours, Contact details */}
          <div className="lg:col-span-5 space-y-6">
            {/* Location Card */}
            <div className="p-6 rounded-2xl bg-neutral-950/70 border border-neutral-800 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 shrink-0">
                <MapPin className="w-5 h-5 stroke-[2]" />
              </div>
              <div>
                <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
                  Flagship Haven
                </h3>
                <p className="text-neutral-400 text-xs sm:text-sm mt-1 leading-relaxed">
                  428 Gourmet Boulevard, Suite 104<br />
                  Culinary Arts District, NY 10012
                </p>
                <div className="mt-2 text-[11px] text-orange-400 font-medium">
                  Valet parking available
                </div>
              </div>
            </div>

            {/* Operating Hours Card */}
            <div className="p-6 rounded-2xl bg-neutral-950/70 border border-neutral-800 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 shrink-0">
                <Clock className="w-5 h-5 stroke-[2]" />
              </div>
              <div className="flex-1">
                <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
                  Kitchen Hours
                </h3>
                <div className="mt-2 space-y-1.5 text-xs sm:text-sm text-neutral-400">
                  <div className="flex justify-between">
                    <span>Monday – Thursday:</span>
                    <span className="text-white font-medium">11:00 AM – 10:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Friday – Saturday:</span>
                    <span className="text-white font-medium">11:00 AM – 11:30 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday:</span>
                    <span className="text-white font-medium">11:30 AM – 9:30 PM</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct Line & Inquiries */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-neutral-950/70 border border-neutral-800 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-400 shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] text-neutral-400 uppercase tracking-wider">Call Directly</div>
                  <a href="tel:+15553498821" className="text-xs font-semibold text-white hover:text-orange-400 transition-colors truncate block">
                    +1 (555) 349-8821
                  </a>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-neutral-950/70 border border-neutral-800 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-400 shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] text-neutral-400 uppercase tracking-wider">Direct Email</div>
                  <a href="mailto:haven@burgershopcraft.com" className="text-xs font-semibold text-white hover:text-orange-400 transition-colors truncate block">
                    haven@burger.shop
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Reservation / Inquiry Form */}
          <div className="lg:col-span-7 bg-neutral-950 border border-neutral-800 rounded-2xl p-6 sm:p-8">
            {isSubmitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-heading text-2xl font-bold text-white uppercase tracking-wider">
                  Request Received!
                </h3>
                <p className="text-neutral-400 text-xs sm:text-sm max-w-md mx-auto leading-relaxed">
                  Thank you, <strong className="text-white">{formData.name}</strong>. Our host team has received your <strong className="text-orange-400">{formData.inquiryType.toLowerCase()}</strong> and will confirm shortly via <strong className="text-white">{formData.email}</strong>.
                </p>
                <div className="pt-4">
                  <button
                    onClick={handleReset}
                    className="px-6 py-2.5 rounded-xl font-semibold text-xs bg-neutral-900 hover:bg-neutral-800 text-white transition-colors"
                  >
                    Send Another Note
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="font-heading text-lg font-bold text-white uppercase tracking-wider mb-2">
                  Reserve a Table or Send a Message
                </h3>

                {/* Inquiry Type Tabs */}
                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2">
                    Inquiry Reason
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {['Table Reservation', 'Private Event', 'Feedback & Press'].map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setFormData({ ...formData, inquiryType: type })}
                        className={`py-2 px-2.5 rounded-xl text-xs font-semibold border transition-all text-center cursor-pointer ${
                          formData.inquiryType === type
                            ? 'border-orange-500 bg-orange-500/10 text-white'
                            : 'border-neutral-800 bg-neutral-900/40 text-neutral-400 hover:border-neutral-700'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Name & Email Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1.5">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Jordan Hayes"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500 placeholder-neutral-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1.5">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. jordan@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500 placeholder-neutral-600"
                    />
                  </div>
                </div>

                {/* Phone & Guests count (if reservation) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1.5">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. +1 (555) 000-0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500 placeholder-neutral-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1.5">
                      Party Size
                    </label>
                    <select
                      value={formData.guests}
                      onChange={(e) => setFormData({ ...formData, guests: e.target.value })}
                      className="w-full px-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500 cursor-pointer"
                    >
                      <option value="1 Guest">1 Guest</option>
                      <option value="2 Guests">2 Guests (Standard Table)</option>
                      <option value="3-4 Guests">3-4 Guests (Booth)</option>
                      <option value="5-8 Guests">5-8 Guests (Chef's Table)</option>
                      <option value="8+ Large Party">8+ Large Party</option>
                    </select>
                  </div>
                </div>

                {/* Message Field */}
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1.5">
                    Notes or Dietary Requests
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Preferred date/time, allergies, or questions..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-orange-500 placeholder-neutral-600 resize-none"
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl font-semibold text-xs sm:text-sm bg-gradient-to-r from-orange-600 to-amber-500 text-white hover:brightness-110 shadow-[0_0_20px_rgba(249,115,22,0.4)] flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Request</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
