import React from 'react';
import { X, Award, Sparkles, Clock, Heart, Shield } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  likesCount: number;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  likesCount,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-orange-400" />
            <h2 className="font-heading text-lg font-bold text-white uppercase tracking-wider">
              Member Passport
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Member Card */}
          <div className="p-5 rounded-xl bg-gradient-to-br from-neutral-900 via-neutral-900 to-orange-950/40 border border-neutral-800 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] text-orange-400 font-bold uppercase tracking-wider">
                  Gold Haven Tier
                </span>
                <h3 className="font-heading text-white text-base font-bold mt-0.5">
                  Alex Mercer
                </h3>
              </div>
              <div className="w-10 h-10 rounded-full bg-orange-500/20 border border-orange-500/30 flex items-center justify-center text-orange-400 font-heading font-bold text-xs">
                AM
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-neutral-800/80 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-neutral-400 uppercase tracking-wider">
                  Haven Points
                </div>
                <div className="text-xl font-heading font-bold text-white flex items-center gap-1.5">
                  <span>{likesCount}</span>
                  <Sparkles className="w-4 h-4 text-orange-400" />
                </div>
              </div>

              <div className="text-right">
                <div className="text-[10px] text-neutral-400 uppercase tracking-wider">
                  Status
                </div>
                <div className="text-xs font-semibold text-emerald-400">
                  Active VIP
                </div>
              </div>
            </div>
          </div>

          {/* Quick Perks */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
              Your Benefits
            </h4>
            <div className="p-3 bg-neutral-900/50 rounded-xl border border-neutral-800 text-xs text-neutral-300 flex items-center gap-3">
              <Award className="w-4 h-4 text-orange-400 shrink-0" />
              <span>Free Artisan Side with every 50 Haven Points</span>
            </div>
            <div className="p-3 bg-neutral-900/50 rounded-xl border border-neutral-800 text-xs text-neutral-300 flex items-center gap-3">
              <Clock className="w-4 h-4 text-orange-400 shrink-0" />
              <span>Priority woodfire kitchen preparation</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
