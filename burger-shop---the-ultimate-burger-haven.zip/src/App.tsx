import React, { useState, useEffect } from 'react';
import { BURGER_ITEMS, BurgerItem, CartItem } from './data/burgers';
import { Navbar, NavTabType } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { OrderModal } from './components/OrderModal';
import { MenuDrawer } from './components/MenuDrawer';
import { CartDrawer } from './components/CartDrawer';
import { ZoomModal } from './components/ZoomModal';
import { SearchModal } from './components/SearchModal';
import { ProfileModal } from './components/ProfileModal';
import { ShopModal } from './components/ShopModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTabType>('home');
  // Default to index 2: "The Ultimate Haven" which corresponds to thumbnail #3 in the screenshot
  const [selectedBurgerIndex, setSelectedBurgerIndex] = useState<number>(2);

  // Likes and counter (starts with 42 matching the screenshot)
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [likesCount, setLikesCount] = useState<number>(42);

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // Modals state
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderTargetBurger, setOrderTargetBurger] = useState<BurgerItem | null>(null);
  const [isMenuDrawerOpen, setIsMenuDrawerOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isShopOpen, setIsShopOpen] = useState(false);

  // Scroll spy to highlight active nav link on scroll
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200;

      const homeElem = document.getElementById('home');
      const aboutElem = document.getElementById('about');
      const contactElem = document.getElementById('contact');

      if (contactElem && scrollPosition >= contactElem.offsetTop) {
        setActiveTab('contact');
      } else if (aboutElem && scrollPosition >= aboutElem.offsetTop) {
        setActiveTab('about');
      } else {
        setActiveTab('home');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Smooth scroll helper
  const scrollToSection = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) {
      const navOffset = 70;
      const elementPosition = elem.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  // Navigation handler
  const handleNavigate = (tab: NavTabType) => {
    setActiveTab(tab);
    if (tab === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (tab === 'about') {
      scrollToSection('about');
    } else if (tab === 'contact') {
      scrollToSection('contact');
    } else if (tab === 'menu') {
      setIsMenuDrawerOpen(true);
    } else if (tab === 'shop') {
      setIsShopOpen(true);
    }
  };

  // Handle like toggle
  const handleToggleLike = () => {
    if (isLiked) {
      setIsLiked(false);
      setLikesCount((prev) => Math.max(0, prev - 1));
    } else {
      setIsLiked(true);
      setLikesCount((prev) => prev + 1);
    }
  };

  // Select burger from thumbnails or search
  const handleSelectBurger = (index: number) => {
    setSelectedBurgerIndex(index);
  };

  const handleSelectBurgerByItem = (burger: BurgerItem) => {
    const idx = BURGER_ITEMS.findIndex((b) => b.id === burger.id);
    if (idx !== -1) {
      setSelectedBurgerIndex(idx);
    }
  };

  // Open customization modal
  const handleOrderNow = (burger: BurgerItem) => {
    setOrderTargetBurger(burger);
    setIsOrderModalOpen(true);
  };

  // Add to cart handler
  const handleAddToCart = (item: CartItem) => {
    setCartItems((prev) => {
      const existing = prev.find(
        (i) =>
          i.burgerId === item.burgerId &&
          i.bunType === item.bunType &&
          i.name === item.name &&
          JSON.stringify(i.extraToppings) === JSON.stringify(item.extraToppings)
      );
      if (existing) {
        return prev.map((i) =>
          i.id === existing.id ? { ...i, quantity: i.quantity + item.quantity } : i
        );
      }
      return [...prev, item];
    });
  };

  // Update item quantity in cart
  const handleUpdateQuantity = (id: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(id);
    } else {
      setCartItems((prev) =>
        prev.map((item) => (item.id === id ? { ...item, quantity: newQty } : item))
      );
    }
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Total cart items count
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const currentBurger = BURGER_ITEMS[selectedBurgerIndex] || BURGER_ITEMS[2];

  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col justify-between selection:bg-orange-500 selection:text-white relative">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        onNavigate={handleNavigate}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        {/* 1. Exact Hero Section from reference image */}
        <HeroSection
          burgers={BURGER_ITEMS}
          selectedIndex={selectedBurgerIndex}
          onSelectBurger={handleSelectBurger}
          onOrderNow={handleOrderNow}
          onViewMenu={() => setIsMenuDrawerOpen(true)}
          onZoomBurger={() => setIsZoomOpen(true)}
          isLiked={isLiked}
          onToggleLike={handleToggleLike}
          likesCount={likesCount}
        />

        {/* 2. Scroll-based About Section */}
        <AboutSection
          onOrderNow={() => handleOrderNow(currentBurger)}
          onViewMenu={() => setIsMenuDrawerOpen(true)}
        />

        {/* 3. Scroll-based Contact Section */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onScrollTo={(id) => handleNavigate(id as NavTabType)}
        onOpenMenu={() => setIsMenuDrawerOpen(true)}
        onOpenShop={() => setIsShopOpen(true)}
      />

      {/* Modals and Drawers for Full Functional Completeness */}
      {/* Burger Customization & Order Modal */}
      <OrderModal
        burger={orderTargetBurger}
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        onAddToCart={handleAddToCart}
      />

      {/* Full Menu Drawer */}
      <MenuDrawer
        isOpen={isMenuDrawerOpen}
        onClose={() => setIsMenuDrawerOpen(false)}
        burgers={BURGER_ITEMS}
        onSelectBurgerToOrder={handleOrderNow}
        onQuickAdd={handleAddToCart}
      />

      {/* Shopping Cart & Checkout Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Fullscreen Zoom Lightbox Modal */}
      <ZoomModal
        burger={currentBurger}
        isOpen={isZoomOpen}
        onClose={() => setIsZoomOpen(false)}
        onOrderNow={handleOrderNow}
        isLiked={isLiked}
        onToggleLike={handleToggleLike}
      />

      {/* Live Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        burgers={BURGER_ITEMS}
        onSelectBurger={(burger) => {
          handleSelectBurgerByItem(burger);
        }}
      />

      {/* Member Passport Profile Modal */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        likesCount={likesCount}
      />

      {/* Merch & Bottled Sauces Shop Modal */}
      <ShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        onAddToCart={handleAddToCart}
        defaultBurgerImage={currentBurger.thumbImage}
      />
    </div>
  );
}
