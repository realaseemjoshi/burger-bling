import heroFlyingImg from '../assets/images/hero_flying_burger_1791214674649.jpg';
import thumbSmokyImg from '../assets/images/thumb_smoky_inferno_1791214690757.jpg';
import thumbWoodfireImg from '../assets/images/thumb_woodfire_classic_1791214703552.jpg';
import thumbPurpleImg from '../assets/images/thumb_purple_onion_gourmet_1791214715644.jpg';

export interface BurgerItem {
  id: string;
  name: string;
  headlineFirst: string;
  headlineSecond: string;
  description: string;
  price: number;
  originalPrice?: number;
  rating: number;
  likesCount: number;
  image: string;
  thumbImage: string;
  calories: string;
  prepTime: string;
  badge?: string;
  ingredients: string[];
  allergens: string[];
}

export const BURGER_ITEMS: BurgerItem[] = [
  {
    id: 'smoky-inferno',
    name: 'Smoky Inferno Smash',
    headlineFirst: 'THE SMOKY',
    headlineSecond: 'INFERNO BLAST',
    description: 'Double flame-seared wagyu patties enveloped in smoke, melted pepper jack, charred jalapeño crunch, and chipotle campfire sauce.',
    price: 14.99,
    originalPrice: 17.99,
    rating: 4.9,
    likesCount: 38,
    image: thumbSmokyImg,
    thumbImage: thumbSmokyImg,
    calories: '860 kcal',
    prepTime: '10-12 mins',
    badge: 'Spicy Favorite',
    ingredients: ['Double Wagyu Patty', 'Smoked Pepper Jack', 'Charred Jalapeños', 'Chipotle Campfire Aioli', 'Crispy Shallots', 'Toasted Brioche'],
    allergens: ['Dairy', 'Gluten', 'Eggs']
  },
  {
    id: 'woodfire-classic',
    name: 'Woodfire Classic Deluxe',
    headlineFirst: 'THE VINTAGE',
    headlineSecond: 'WOODFIRE CHEESE',
    description: 'Heritage aged Wisconsin cheddar draped over a thick hand-pressed Angus beef patty with crisp lettuce, heirloom tomato, and house dill relish.',
    price: 13.50,
    originalPrice: 15.50,
    rating: 4.8,
    likesCount: 35,
    image: thumbWoodfireImg,
    thumbImage: thumbWoodfireImg,
    calories: '790 kcal',
    prepTime: '8-10 mins',
    badge: 'Classic Heritage',
    ingredients: ['Hand-Pressed Angus Beef', 'Aged Wisconsin Cheddar', 'Crisp Iceberg Lettuce', 'Vine-Ripe Tomato', 'House Pickle Relish', 'Toasted Sesame Bun'],
    allergens: ['Dairy', 'Gluten']
  },
  {
    id: 'ultimate-haven',
    name: 'The Ultimate Haven',
    headlineFirst: 'THE ULTIMATE',
    headlineSecond: 'BURGER HAVEN',
    description: 'Welcome to our Burger Paradise, where every bite is a journey into flavor perfection! Indulge in a symphony of premium ingredients, expertly crafted patties, and mouthwatering sauces.',
    price: 15.99,
    originalPrice: 18.99,
    rating: 5.0,
    likesCount: 42,
    image: heroFlyingImg,
    thumbImage: heroFlyingImg,
    calories: '920 kcal',
    prepTime: '12-14 mins',
    badge: "Chef's Masterpiece",
    ingredients: ['Prime Dry-Aged Beef', 'Golden Melted Cheddar', 'Curled Hydroponic Lettuce', 'Roma Tomato Slab', 'Secret Haven Drizzle', 'Glazed Sesame Crown'],
    allergens: ['Dairy', 'Gluten', 'Eggs', 'Sesame']
  },
  {
    id: 'purple-velvet',
    name: 'Purple Velvet Truffle',
    headlineFirst: 'THE PURPLE',
    headlineSecond: 'VELVET GOURMET',
    description: 'Sumptuous black truffle aioli with shaved purple sweet red onions, baby wild arugula, cherry tomato compote, and caramelized brioche.',
    price: 16.49,
    originalPrice: 19.99,
    rating: 4.9,
    likesCount: 29,
    image: thumbPurpleImg,
    thumbImage: thumbPurpleImg,
    calories: '810 kcal',
    prepTime: '10-12 mins',
    badge: 'Truffle Specialty',
    ingredients: ['Black Angus Chuck Patty', 'Marinated Purple Onions', 'Black Truffle Aioli', 'Wild Baby Arugula', 'Slow-Roasted Cherry Tomatoes', 'Artisan Brioche'],
    allergens: ['Dairy', 'Gluten', 'Eggs']
  }
];

export interface CartItem {
  id: string;
  burgerId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  bunType: string;
  extraToppings: string[];
}
